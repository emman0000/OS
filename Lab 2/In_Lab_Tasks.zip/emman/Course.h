#include "Course.h"
#include "Student.h"
#include "Teacher.h"

// Constructor implementation
Course::Course(const std::string& name) : name(name) {}

// Method to add a student to the course
void Course::addStudent(Student* student) {
    students.push_back(student);
}

// Method to add a teacher to the course
void Course::addTeacher(Teacher* teacher) {
    teachers.push_back(teacher);
}

// Method to get the course name
const std::string& Course::getName() const {
    return name;
}

// Method to get the list of students enrolled in the course
const std::vector<Student*>& Course::getStudents() const {
    return students;
}

// Method to get the list of teachers teaching the course
const std::vector<Teacher*>& Course::getTeachers() const {
    return teachers;
}
