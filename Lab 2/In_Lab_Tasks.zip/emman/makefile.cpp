Coutputfile main.o Student.o Course.o 
g++ Student.o Teacher.o Course.o main.o - outputfile

Student.o : Student.cpp Student.h
g++ -c Student.cpp

Teacher.o : Teacher.cpp Teacher.h
g++ -c Teacher.cpp

Course.o : Course.cpp Course.h
g++ -c Course.cpp

main.o : main.cpp
g++ -c main.cpp

clean:
rm*.o outputfile

run:outputfile
./outputfile
