#include "Teacher.h"
#include "Course.h"

// Constructor implementation
Teacher::Teacher(const std::string& name) : name(name) {}

// Method to assign a course to the teacher
void Teacher::teachCourse(Course* course) {
    teachingCourses.push_back(course);
}

// Method to get the teacher's name
const std::string& Teacher::getName() const {
    return name;
}

// Method to get the list of courses taught by the teacher
const std::vector<Course*>& Teacher::getTeachingCourses() const {
    return teachingCourses;

