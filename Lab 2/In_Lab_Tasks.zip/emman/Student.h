#include "Student.h"
#include "Course.h"

// Constructor implementation
Student::Student(const std::string& name) : name(name) {}

// Method to enroll a course
void Student::enrollCourse(Course* course) {
    enrolledCourses.push_back(course);
}

// Method to get the student's name
const std::string& Student::getName() const {
    return name;
}

// Method to get the list of enrolled courses
const std::vector<Course*>& Student::getEnrolledCourses() const {
    return enrolledCourses;
